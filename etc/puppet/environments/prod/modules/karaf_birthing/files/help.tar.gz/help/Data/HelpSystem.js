MadCap.Utilities.Xhr._FilePathToXmlStringMap.Add(
	'HelpSystem',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<WebHelpSystem LiveHelpOutputId=\"Je5Rs4+VAH9yGFp01UKjhY5lxCtq3p0FPediWNG45lf19veygAOV89EQnImZ5y57C7Y7gQcU6vTD9eu8UqGmGRHCClpwXY/PF3Gh2wKesUVFQlTK8FRXp16zxJd5JzuuvhsD5Xi649X2TypUabJYobIN2n8/4WbKS9ngx9yeWQ9pgyv2ZWZ2wlLK182TUyvqj751oftPYmwmRNUiqw3yC+da+xe0qUG9h5lVt6OGXcaJdA1fWhlsG+cQMnnZUPFueEayN9C/ens/hw5R37D5WeUwwtltmlOPkwtV61j+oERI2m/FMzI0kXS2H46tMnDxkWb5lQ6T/+9FsHV8BczlBRPqFbM9DcjdQSIE6f1aIJPXZolIrM+JqPwtSiBVpUWXC6MAsTh+co9JUSOUIaSaRaDXIAIkNf5ujm2gKiSdXetjWD54cTgk9/keK4U8H8fD0tgxi7qqMBY32f6XMSRXy/QsXKuSA+hK5hSJ/lnkfY/hkvKUG2koEaHxH5gKgkbMSvLyspb17kfjZeYgMErHV1LuUXtUIUgeD2YBLO2LGJGqZwnakR5KpDxNr0fKGEcyn9wLxsFqGO2YGAFg6YtX5ub5BWYhJ+QwsY7Jzvdi9B5xeNks/rSCsWAyvpHoVSMUC6SVRqnVjCXCo0I+hn9Pld6cIeWk48wi6PkLuZpe6eM=\" LiveHelpServer=\"http://webhelp.actiance.com/\" DefaultUrl=\"Content/PortolaUserGuide/alcatraz_documentation.htm\" Toc=\"Data/Toc.js\" Index=\"Data/Index.js\" Concepts=\"Data/Concepts.xml\" BrowseSequence=\"Data/BrowseSequence.js\" Glossary=\"Data/Glossary.js\" SearchDatabase=\"Data/Search.xml\" Alias=\"Data/Alias.xml\" Synonyms=\"Data/Synonyms.xml\" SkinName=\"Vantage\" Skins=\"Vantage\" BuildTime=\"4/7/2017 7:18:40 PM\" BuildVersion=\"9.0.0.0\" TargetType=\"WebHelp2\" SkinTemplateFolder=\"Skin/\" InPreviewMode=\"false\" MoveOutputContentToRoot=\"false\" MakeFileLowerCase=\"false\" UseCustomTopicFileExtension=\"false\">' +
	'    <CatapultSkin Version=\"1\" SkinType=\"WebHelp2\" Comment=\"HTML5 skin\" Anchors=\"Width,Height\" Width=\"800\" Height=\"600\" Top=\"0\" Left=\"0\" Bottom=\"0\" Right=\"0\" Tabs=\"TOC\" DefaultTab=\"TOC\" UseBrowserDefaultSize=\"True\" UseDefaultBrowserSetup=\"true\" Title=\"Alcatraz Online Help\" AutoSyncTOC=\"true\" NavigationLinkTop=\"false\" BrowserSetup=\"Toolbar,Menu,StatusBar,Resizable\" Name=\"Vantage\">' +
	'        <TopicToolbar EnableCustomLayout=\"true\" Buttons=\"Home|PreviousTopic|CurrentTopicIndex|NextTopic\" />' +
	'        <Toolbar EnableCustomLayout=\"true\" Buttons=\"\">' +
	'            <Script />' +
	'        </Toolbar>' +
	'        <WebHelpOptions NavigationPaneWidth=\"250\" />' +
	'    </CatapultSkin>' +
	'</WebHelpSystem>'
);
